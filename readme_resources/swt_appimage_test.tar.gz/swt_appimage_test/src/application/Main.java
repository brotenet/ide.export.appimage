package application;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTApplication;
import org.eclipse.swt.environment.Environment;
import org.eclipse.swt.environment.WindowManager;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import application.forms.FMain;

public class Main extends SWTApplication{

	public static void main(String[] args) {
		Display display = new Display();
		
		Shell shell = WindowManager.newShell(display, true, true);
		shell.setText("Hello world of AppImage!!");
		shell.setImage(Environment.Resources.getImageFromResource("/application/appimage.png"));
		shell.setSize(800, 600);
		FMain main_form = new FMain(shell, SWT.NONE);
		main_form.setData("arguments", collectArguments(args));
		WindowManager.open(shell);

	}

}
