package application.forms;

import org.eclipse.swt.SWT;
import org.eclipse.swt.environment.Environment.Session;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

public class FMain extends Composite {
	private Text text;

	public FMain(Composite parent, int style) {
		super(parent, style);
		setLayout(new GridLayout(1, false));

		Button btnSysInfo = new Button(this, SWT.NONE);
		btnSysInfo.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				text.setText("Hello! Your System infor mation is as follows:" + Session.LineSeparator() + "OS: "
						+ Session.OperatingSystemName() + " " + Session.OperatingSystemArchitecture() + " "
						+ Session.OperatingSystemVersion() + Session.LineSeparator() + "Username: " + Session.UserName()
						+ Session.LineSeparator() + "UserHome: " + Session.UserHome());
			}
		});
		btnSysInfo.setImage(new Image(null, FMain.class.getResourceAsStream("/application/settings.png")));
		btnSysInfo.setText("Click Here to get System Info");

		text = new Text(this, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.MULTI);
		text.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));

	}
}
